/**
  **************************************************************************
  * File   : DAC/OneChannelDMA_Escalator/readme.txt
  * Version: V1.2.8
  * Date   : 2020-11-27
  * Brief  : Use DAC1 to generate an escalator waveform.
  **************************************************************************
  */

  @Description
    This demo is based on the AT-START-F403 board,in this demo,PA4 output an escalator waveform.    
