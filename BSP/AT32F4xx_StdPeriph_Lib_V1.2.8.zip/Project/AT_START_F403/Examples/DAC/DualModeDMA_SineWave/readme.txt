/**
  **************************************************************************
  * File   : DAC/DualModeDMA_SineWave/readme.txt
  * Version: V1.2.8
  * Date   : 2020-11-27
  * Brief  : Use DAC1/2 to generate sine waveform.
  ************************************************************************** 
  */

  @Description
    This demo is based on the AT-START-F403 board,in this demo,PA4 PA5 output sine waveform   

