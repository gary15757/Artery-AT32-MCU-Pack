/**
  ******************************************************************************
  * File   : CortexM4/FPU_LCD_Display/readme.txt 
  * Version: V1.2.8
  * Date   : 2020-11-27
  * Brief  : cortex-m4 fpu
  ******************************************************************************
  * @Description
  * 
  *   This demo is based on the AT-START-F403 board,in this demo, test the FPU efficiency.
  * Using LCD to dispaly the FPU effect.Using FPU conversion speed 17 times faster than not
  * using FPU function. 
  * 
  ******************************************************************************
  */ 

