/**
  **************************************************************************
  * File   : time.h
  * Version: V1.2.8
  * Date   : 2020-11-27
  * Brief  : none
  **************************************************************************
  */

#ifndef _TIMER_H
#define _TIMER_H
#include "at32f4xx.h"

void TMR3_Int_Init(u16 arr,u16 psc);
#endif
