/**
  **************************************************************************
  * File   : usart.h
  * Version: V1.2.8
  * Date   : 2020-11-27
  * Brief  : none
  **************************************************************************
  */
#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 

void Uart1_Init(u32 bound);
#endif


